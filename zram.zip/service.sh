#!/system/bin/sh

MODDIR=${0%/*}
CONFIG="$MODDIR/zram_config.conf"

{
    resetprop ro.boot.flash.locked 1
    resetprop ro.boot.verifiedbootstate green
    resetprop ro.secureboot.lockstate locked
    resetprop ro.boot.vbmeta.device_state locked
    resetprop -n ro.boot.vbmeta.digest
} 2>/dev/null

[ -f "$CONFIG" ] || exit 0

echo_values() {
    [ $# -eq 3 ] && echo $1 > /sys/block/zram$2/$3 2>/dev/null
}

apply_zram() {
    /system/bin/swapoff /dev/block/zram0 2>/dev/null

    su -c insmod $MODDIR/zsmalloc.ko
    sleep 3
    su -c insmod $MODDIR/zram.ko

    local try=0
    while [ ! -e /dev/block/zram0 ] && [ $try -lt 30 ]; do
        sleep 1
        try=$((try+1))
    done
    [ ! -e /dev/block/zram0 ] && return 1

    source "$CONFIG"
    [ -z "$algorithm" ] || [ -z "$size" ] && return 1

    echo 1 > /sys/block/zram0/reset 2>/dev/null
    echo_values "$algorithm" 0 comp_algorithm
    echo_values "$size" 0 disksize
    /system/bin/mkswap /dev/block/zram0 2>/dev/null
    /system/bin/swapon /dev/block/zram0 -p 32758 2>/dev/null || \
    /system/bin/swapon /dev/block/zram0 2>/dev/null
}

apply_zram