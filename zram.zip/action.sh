#!/system/bin/sh

MODDIR=${0%/*}

algorithms="lz4 lz4k lz4k_oplus lz4kd lz4hc zstd zstdn lzo lzo-rle 842 deflate"
sizes="官方大小 7516192768 8053063680 8589934592 9126805504 10737418240 12884901888 15032385536 17179869184 25769803776 0"

is_php110() {
    [ "$(getprop ro.product.device)" = "PHP110" ] && return 0
    [ "$(getprop ro.product.model)" = "PHP110" ] && return 0
    return 1
}

calculate_recommended_size() {
    physical_mem_kb=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
    
    if [ $physical_mem_kb -lt 8388608 ]; then
        echo 8589934592
    elif [ $physical_mem_kb -lt 12582912 ]; then
        echo 12884901888
    elif [ $physical_mem_kb -lt 16777216 ]; then
        echo 17179869184
    else
        echo 25769803776
    fi
}

show_device_info() {
  echo "🔧 设备: $(getprop ro.product.model || echo '未知')"
  echo "🔄 Android: $(getprop ro.build.version.release || echo '未知')"
  echo "⚙️ 内核: $(uname -r || echo '未知')"
}

get_real_ram_bytes() {
  awk '/MemTotal/ {if($2>0) print $2*1024; else print 0}' /proc/meminfo 2>/dev/null || echo "0"
}

check_dual_zram() {
  [ -e /sys/block/zram0 ] && [ -e /sys/block/zram1 ] && echo "是" || echo "否"
}

get_active_algorithm() {
  alg=$(cat /sys/block/zram0/comp_algorithm 2>/dev/null | grep -o '\[[^]]*\]' | tr -d '[]')
  echo "${alg:-lz4kd}"
}

get_zram1_size() {
  cat /sys/block/zram1/disksize 2>/dev/null || echo "0"
}

wait_key() {
  getevent -qt 1 >/dev/null 2>&1
  while true; do
    event=$(getevent -lqc 1 2>/dev/null | {
      while read -r line; do
        case "$line" in
          *KEY_VOLUMEDOWN*DOWN*) echo "down" && break ;;
          *KEY_VOLUMEUP*DOWN*) echo "up" && break ;;
          *KEY_POWER*DOWN*)
            input keyevent KEY_POWER
            echo "power" && break ;;
        esac
      done
    })
    [ -n "$event" ] && echo "$event" && return
    usleep 50000
  done
}

countdown() {
  local secs=$1
  while [ $secs -gt 0 ]; do
    echo -ne "⏳ ${secs}秒后退出...\033[0K\r"
    sleep 1
    : $((secs--))
  done
  echo -e "\033[0K\r"
}

RAM_BYTES=$(get_real_ram_bytes)
IS_DUAL_ZRAM=$(check_dual_zram)
current_alg=$(get_active_algorithm)
ZRAM1_SIZE=$(get_zram1_size)

if is_php110; then
  RECOMMENDED_SIZE=$(calculate_recommended_size)
fi

index=0
alg_count=$(echo "$algorithms" | wc -w)
for alg in $algorithms; do
  if [ "$alg" = "$current_alg" ]; then break; fi
  index=$((index + 1))
done
[ $index -ge $alg_count ] && index=0 && current_alg=$(echo "$algorithms" | cut -d' ' -f$((index + 1)))

current_size=$(cat /sys/block/zram0/disksize 2>/dev/null || echo 0)
size_index=0
j=0
for sz in $sizes; do
  if [ "$sz" = "官方大小" ]; then
    if is_php110 && [ "$current_size" -eq "$RECOMMENDED_SIZE" ]; then
      size_index=$j
      break
    elif ! is_php110 && [ "$current_size" -eq "$ZRAM1_SIZE" ]; then
      size_index=$j
      break
    fi
  elif [ "$sz" -eq "$current_size" ]; then
    size_index=$j
    break
  fi
  j=$((j + 1))
done
size_count=$(echo "$sizes" | wc -w)
[ $size_index -ge $size_count ] && size_index=0

show_menu() {  
  clear  
  echo "ZRAM 配置管理器² 😋"  
  echo "----------------------------------"  
  show_device_info  
  echo "----------------------------------"  
  echo "📊 物理内存: $(echo "$RAM_BYTES" | awk '{if($1<=0) print "未知"; else printf "%.1fGB", $1/1024/1024/1024}')"  
  echo "💽 双ZRAM: $IS_DUAL_ZRAM"  
  echo "----------------------------------"  
  echo "📦 压缩算法选择:"  
  local i=0  
  for alg in $algorithms; do  
    if [ $i -eq $index ]; then  
      echo "➡️  $alg [当前: $(get_active_algorithm)]"  
    else  
      echo "    $alg"  
    fi  
    i=$((i + 1))  
  done  
  echo "----------------------------------"  
  echo "⚠️设置的是你的zram0大小，麻烦不要按照物理内存修改⚠️"  
  echo "💾 ZRAM 0 大小设置:"  
  local j=0  
  for sz in $sizes; do  
    if [ "$sz" -eq "0" ]; then
      continue
    fi
    if [ "$sz" = "官方大小" ]; then  
      if is_php110; then
        human_sz="官方大小 (zram0=物理内存)"
      else
        human_sz="官方大小 (zram0=zram1)"  
      fi  
    else  
      human_sz=$(echo "$sz" | awk '{printf "%.1fGB", $1/1024/1024/1024}')  
    fi  
    [ $j -eq $size_index ] && echo "➡️  $human_sz" || echo "    $human_sz"  
    j=$((j + 1))  
  done  
  echo "----------------------------------"  
  echo "🔽 音量下：切换算法 | 🔼 音量上：切换大小"  
  echo "🔌 电源键：应用并退出"  
  echo "----------------------------------"  
  echo "配置将保存到模块目录: $MODDIR/zram_config.conf"  
  echo ""  
}

while true; do
  show_menu
  case $(wait_key) in
    "down")
      index=$(( (index + 1) % alg_count ))
      current_alg=$(echo "$algorithms" | cut -d' ' -f$((index + 1)))
      ;;
    "up")
      size_index=$(( (size_index + 1) % size_count ))
      ;;
    "power")
      selected_alg=$(echo "$algorithms" | cut -d' ' -f$((index + 1)))
      selected_size=$(echo "$sizes" | cut -d' ' -f$((size_index + 1)))
      
      clear
      echo "🛠️ 正在应用配置..."
      echo "----------------------------------"
      echo "选定算法: $selected_alg"
      
      if [ "$selected_size" = "官方大小" ]; then
        if is_php110; then
          ACTUAL_SIZE_TO_APPLY=$RECOMMENDED_SIZE
          echo "目标大小: $(echo "$ACTUAL_SIZE_TO_APPLY" | awk '{printf "%.1fGB", $1/1024/1024/1024}') (物理内存)"
        else
          ACTUAL_SIZE_TO_APPLY=$ZRAM1_SIZE
          echo "目标大小: $(echo "$ACTUAL_SIZE_TO_APPLY" | awk '{printf "%.1fGB", $1/1024/1024/1024}')"
        fi
      else
        ACTUAL_SIZE_TO_APPLY=$selected_size
        echo "目标大小: $(echo "$ACTUAL_SIZE_TO_APPLY" | awk '{printf "%.1fGB", $1/1024/1024/1024}')"
      fi
      
      echo "双ZRAM: $IS_DUAL_ZRAM"
      echo "----------------------------------"

      su -c "
        swapoff /dev/block/zram0 2>/dev/null
        echo 1 > /sys/block/zram0/reset
        echo $selected_alg > /sys/block/zram0/comp_algorithm
        echo $ACTUAL_SIZE_TO_APPLY > /sys/block/zram0/disksize
        mkswap /dev/block/zram0 >/dev/null
        swapon /dev/block/zram0 -p 32758 >/dev/null
      "

      sleep 1
      new_alg=$(get_active_algorithm)
      new_size=$(cat /sys/block/zram0/disksize 2>/dev/null || echo "0")

      clear
      echo "🔧 ZRAM 配置管理器"
      echo "----------------------------------"

      if { [ "$selected_size" = "官方大小" ] && [ "$new_size" -eq "$ACTUAL_SIZE_TO_APPLY" ]; } || \
         { [ "$new_alg" = "$selected_alg" ] && [ "$new_size" -eq "$ACTUAL_SIZE_TO_APPLY" ]; }; then
        echo "✅ 全部都搞定了❛˓◞˂̵✧"
        echo "实际算法: $new_alg"
        
        if [ "$selected_size" = "官方大小" ]; then
          saved_size="$ACTUAL_SIZE_TO_APPLY"
          if is_php110; then
            echo "实际大小: $(echo "$saved_size" | awk '{printf "%.1fGB", $1/1024/1024/1024}') (物理内存)"
          else
            echo "实际大小: $(echo "$saved_size" | awk '{printf "%.1fGB", $1/1024/1024/1024}')"
          fi
        else
          saved_size="$selected_size"
          echo "实际大小: $(echo "$saved_size" | awk '{printf "%.1fGB", $1/1024/1024/1024}')"
        fi
        
        CONFIG_FILE="$MODDIR/zram_config.conf"
        echo "ℹ️ 正在保存配置到文件: $CONFIG_FILE..."

        su -c "cat > \"$CONFIG_FILE\" <<EOF
algorithm=$new_alg
size=$saved_size
EOF"

        if [ $? -eq 0 ]; then
          echo "✅ 配置文件保存成功。"
          MODULE_PROP="$MODDIR/module.prop"
          if [ -f "$MODULE_PROP" ]; then
            if [ "$selected_size" = "官方大小" ]; then
              if is_php110; then
                human_size="$(echo "$ACTUAL_SIZE_TO_APPLY" | awk '{printf "%.1fGB", $1/1024/1024/1024}')"
              else
                human_size="$(echo "$ACTUAL_SIZE_TO_APPLY" | awk '{printf "%.1fGB", $1/1024/1024/1024}')"
              fi
            else
              human_size=$(echo "$selected_size" | awk '{printf "%.1fGB", $1/1024/1024/1024}')
            fi
            new_description="description=当前已生效 [ZRAM大小($human_size) 压缩算法($new_alg)]"
            su -c "sed -i 's/^description=.*/$new_description/' \"$MODULE_PROP\""
          fi
        else
          echo "❌ 配置文件保存失败！请检查权限。"
        fi
      else
        echo "❌ 设置失败或部分未生效"
        echo "预期算法: $selected_alg, 实际算法: $new_alg"
        if [ "$selected_size" = "官方大小" ]; then
          echo "预期大小: $ACTUAL_SIZE_TO_APPLY, 实际大小: $new_size"
        else
          echo "预期大小: $ACTUAL_SIZE_TO_APPLY, 实际大小: $new_size"
        fi
      fi
      echo "----------------------------------"
      countdown 3
      exit 0
      ;;
  esac
done